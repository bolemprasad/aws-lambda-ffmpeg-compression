import json
import boto3
import subprocess
import os
import tempfile
from urllib.parse import unquote_plus

# Initialize S3 client
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    # Get the S3 bucket and file information from the event
    source_bucket = event['Records'][0]['s3']['bucket']['name']
    source_key = unquote_plus(event['Records'][0]['s3']['object']['key'])
    destination_bucket = 'output-video-bucket-9100246253-1'  # Replace with your actual destination bucket name

    # Create a temporary file to store the downloaded video in /tmp directory
    with tempfile.NamedTemporaryFile(delete=False, dir='/tmp') as tmp_file:
        # Download the video from S3
        s3_client.download_file(source_bucket, source_key, tmp_file.name)

        # Define the path to save the compressed video
        base, ext = os.path.splitext(source_key)
        compressed_file_path = os.path.join('/tmp', f'{base}_compressed{ext}')

        # Run ffmpeg to compress the video (this will use the layer's ffmpeg binary)
        command = ['/opt/bin/ffmpeg', '-i', tmp_file.name, '-vcodec', 'libx264', '-crf', '28', compressed_file_path]
        try:
            subprocess.run(command, check=True)
            print(f"Video compression successful: {compressed_file_path}")
        except subprocess.CalledProcessError as e:
            print(f"Error during video compression: {e}")
            return {
                'statusCode': 500,
                'body': json.dumps(f'Error during video compression: {e}')
            }

        # Upload the compressed video to the destination bucket
        compressed_file_key = f"compressed/{os.path.basename(source_key)}"
        s3_client.upload_file(compressed_file_path, destination_bucket, compressed_file_key)

        print(f"Compressed video uploaded to {destination_bucket}/{compressed_file_key}")

    return {
        'statusCode': 200,
        'body': json.dumps('Video compression and upload successful')
    }
